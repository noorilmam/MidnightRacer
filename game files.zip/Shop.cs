// ============================================================
//  Shop.cs  –  Pre-race item shop
// ============================================================
namespace MidnightCircuit
{
    public static class Shop
    {
        private static readonly List<Item> _catalogue = new()
        {
            new Nitro(),
            new PerformanceTires(),
            new EmpJammer()
        };

        public static void Open(Player player)
        {
            UI.Banner("  MIDNIGHT CIRCUIT SHOP");

            bool shopping = true;
            while (shopping)
            {
                Console.WriteLine($"\n  Cash available: ${player.Cash}");
                Console.WriteLine();

                for (int i = 0; i < _catalogue.Count; i++)
                    Console.WriteLine($"  [{i + 1}] {_catalogue[i]}");

                Console.WriteLine($"  [0] Leave shop");
                Console.WriteLine();

                int choice = UI.ReadInt("  Select item (0 to exit): ", 0, _catalogue.Count);

                if (choice == 0)
                {
                    shopping = false;
                }
                else
                {
                    Item selected = _catalogue[choice - 1];
                    if (player.Cash < selected.Cost)
                    {
                        Console.WriteLine($"  ❌  Not enough cash! You have ${player.Cash}, need ${selected.Cost}.");
                    }
                    else
                    {
                        player.SpendCash(selected.Cost);

                        // Create a new instance (so the catalogue item isn't consumed)
                        Item newItem = choice switch
                        {
                            1 => new Nitro(),
                            2 => new PerformanceTires(),
                            3 => new EmpJammer(),
                            _ => throw new InvalidOperationException()
                        };

                        player.Inventory.AddItem(newItem);
                        Console.WriteLine($"  ✅  Purchased {newItem.Name}. Cash remaining: ${player.Cash}");
                    }
                }
            }
        }
    }
}
