// ============================================================
//  Game.cs  –  Game Controller / Game Engine class
//              Controls overall game flow (required by rubric)
// ============================================================
namespace MidnightCircuit
{
    public class Game
    {
        private const int MaxLevels = 4;
        private const int WinCash   = 1500;
        private const int WinRep    = 200;
        private const int LossRep   = -50;

        private Player _player = null!;

        // ── Entry point ───────────────────────────────────────
        public void Start()
        {
            ShowTitleScreen();
            ShowMainMenu();
        }

        // ── Main menu (required: menu-driven input) ───────────
        private void ShowMainMenu()
        {
            bool running = true;
            while (running)
            {
                UI.Banner("  MAIN MENU");
                Console.WriteLine("  [1] New Game");
                Console.WriteLine("  [2] How to Play");
                Console.WriteLine("  [3] Exit");
                Console.WriteLine();

                try
                {
                    int choice = UI.ReadInt("  Select: ", 1, 3);
                    switch (choice)
                    {
                        case 1: NewGame();    break;
                        case 2: ShowHelp();   break;
                        case 3: running = false; break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"  [Error] Unexpected error: {ex.Message}");
                }
            }

            Console.WriteLine("  Goodbye. See you at midnight.");
        }

        private void NewGame()
        {
            string name = UI.ReadName("  Enter your racer name: ");
            _player = new Player(name);

            Console.WriteLine($"\n  Welcome to the underground, {_player.Name}.");
            Console.WriteLine($"  Starting cash: ${_player.Cash}");
            Console.WriteLine();

            for (int level = 1; level <= MaxLevels; level++)
            {
                if (!RunLevel(level)) break;
            }

            ShowFinalStats();
        }

        // ── Level loop ────────────────────────────────────────
        private bool RunLevel(int level)
        {
            try
            {
                UI.Banner($"  LEVEL {level}  -  {LevelBuilder.LevelDescription(level)}");
                Console.WriteLine();

                // Reputation gate for higher levels
                int repRequired = (level - 2) * 200;
                if (level >= 3 && _player.Reputation < repRequired)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"  [LOCKED] Level {level} requires {repRequired} Reputation." +
                                      $" You have {_player.Reputation}.");
                    Console.ResetColor();
                    Console.WriteLine("  The underground doesn't think you're ready. Game over.");
                    return false;
                }

                Console.WriteLine($"  Reputation: {_player.Reputation} | Cash: ${_player.Cash}");
                Console.WriteLine();

                // Pre-race options menu
                ShowPreRaceMenu();

                // Build rivals for this level
                var rivals = LevelBuilder.BuildRivals(level);
                Console.WriteLine();
                Console.WriteLine("  Tonight's rivals:");
                foreach (var r in rivals)
                    Console.WriteLine($"    * {r.Name} ({r.GetType().Name})");
                Console.WriteLine();

                // Run the race
                var race = new Race(_player, rivals, level);
                bool won = race.Run();

                Console.WriteLine();
                if (won)
                {
                    _player.EarnCash(WinCash);
                    _player.EarnRep(WinRep);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"  +${WinCash} cash  |  +{WinRep} reputation earned.");
                    Console.ResetColor();
                }
                else
                {
                    _player.EarnRep(LossRep);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"  {LossRep} reputation penalty.");
                    Console.ResetColor();

                    Console.WriteLine("\n  Continue to next level? [1] Yes  [2] No");
                    int cont = UI.ReadInt("  -> ", 1, 2);
                    if (cont == 2) return false;
                }

                if (level == MaxLevels)
                {
                    UI.Banner("  YOU CONQUERED THE MIDNIGHT CIRCUIT!");
                    return false;
                }

                Console.WriteLine("\n  Press ENTER to continue to the next level...");
                Console.ReadLine();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"  [Error] An error occurred during Level {level}: {ex.Message}");
                return false;
            }
        }

        // ── Pre-race menu ─────────────────────────────────────
        private void ShowPreRaceMenu()
        {
            bool ready = false;
            while (!ready)
            {
                UI.Header("PRE-RACE");
                Console.WriteLine("  [1] Visit Shop");
                Console.WriteLine("  [2] View Inventory");
                Console.WriteLine("  [3] View Player Stats");
                Console.WriteLine("  [4] Start Race");
                Console.WriteLine();

                try
                {
                    int choice = UI.ReadInt("  Select: ", 1, 4);
                    switch (choice)
                    {
                        case 1: Shop.Open(_player);          break;
                        case 2: _player.Inventory.ShowInventory(); break;
                        case 3: _player.DisplayStats();      break;
                        case 4: ready = true;                break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"  [Error] {ex.Message}");
                }
            }
        }

        // ── Help screen ───────────────────────────────────────
        private static void ShowHelp()
        {
            UI.Banner("  HOW TO PLAY");
            Console.WriteLine("  - Each race is turn-based. On your turn, choose an action.");
            Console.WriteLine("  - Accelerate: Move forward at your current speed.");
            Console.WriteLine("  - Use Item  : Consume an item from your inventory.");
            Console.WriteLine("  - Defend    : Reduce speed but recover durability.");
            Console.WriteLine("  - Hazards can hit anyone each turn.");
            Console.WriteLine("  - Win races to earn Cash and Reputation.");
            Console.WriteLine("  - Higher Reputation unlocks harder levels.");
            Console.WriteLine();
            Console.WriteLine("  Press ENTER to return...");
            Console.ReadLine();
        }

        // ── Title screen ──────────────────────────────────────
        private static void ShowTitleScreen()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(@"
  ================================================
    MIDNIGHT CIRCUIT : URBAN RACER
    A Turn-Based Street Racing Strategy Game
  ================================================
    ");
            Console.ResetColor();
            Console.WriteLine("  Underground racing. Strategic decisions. No mercy.");
            Console.WriteLine();
        }

        // ── End-of-game stats ─────────────────────────────────
        private void ShowFinalStats()
        {
            Console.WriteLine();
            UI.Banner("  FINAL STATS");
            _player.DisplayStats();
            Console.WriteLine();
        }
    }
}
