// ============================================================
//  Player.cs  –  User-controlled racer (extends Racer)
// ============================================================
namespace MidnightCircuit
{
    public class Player : Racer
    {
        // ── Private backing fields ────────────────────────────
        private int _cash;
        private int _reputation;

        // ── Public properties ─────────────────────────────────
        public int Cash
        {
            get => _cash;
            private set
            {
                if (value < 0) throw new ArgumentOutOfRangeException(nameof(value), "Cash cannot go negative.");
                _cash = value;
            }
        }

        public int Reputation
        {
            get => _reputation;
            private set => _reputation = value;
        }

        public Inventory         Inventory            { get; } = new Inventory();
        public int               HazardResistTurnsLeft { get; set; } = 0;

        private bool _nitroUsedThisTurn = false;

        // ── Constructor ───────────────────────────────────────
        public Player(string name) : base(name, speed: 5, durability: 100, totalLaps: 10)
        {
            _cash       = 3000;
            _reputation = 0;
        }

        // ── Reset for each race ───────────────────────────────
        public void ResetForRace(int totalLaps)
        {
            if (totalLaps <= 0) throw new ArgumentOutOfRangeException(nameof(totalLaps), "Total laps must be positive.");
            LapsLeft             = totalLaps;
            HazardResistTurnsLeft = 0;
            _nitroUsedThisTurn   = false;
            RestoreSpeed();
        }

        // ── Economy ───────────────────────────────────────────
        public bool SpendCash(int amount)
        {
            if (amount < 0) throw new ArgumentOutOfRangeException(nameof(amount), "Spend amount cannot be negative.");
            if (amount > Cash) return false;
            Cash -= amount;
            return true;
        }

        public void EarnCash(int amount)
        {
            if (amount < 0) throw new ArgumentOutOfRangeException(nameof(amount), "Earn amount cannot be negative.");
            Cash += amount;
        }

        public void EarnRep(int amount) => Reputation += amount;

        // ── IDisplayable override ─────────────────────────────
        public override void DisplayStats()
        {
            Console.WriteLine($"  Name       : {Name}");
            Console.WriteLine($"  Speed      : {Speed}");
            Console.WriteLine($"  Durability : {Durability}");
            Console.WriteLine($"  Laps Left  : {LapsLeft}");
            Console.WriteLine($"  Cash       : ${Cash}");
            Console.WriteLine($"  Reputation : {Reputation}");
        }

        // ── PerformAction override (menu-driven) ──────────────
        public override void PerformAction(Race race)
        {
            if (race == null) throw new ArgumentNullException(nameof(race));

            Console.WriteLine();
            UI.Header("YOUR TURN");
            Console.WriteLine($"  Status -> {this}");
            Console.WriteLine($"  Cash: ${Cash}  |  Reputation: {Reputation}");
            Console.WriteLine();
            Console.WriteLine("  [1] Accelerate   (advance at full speed)");
            Console.WriteLine("  [2] Use Item     (consume item from inventory)");
            Console.WriteLine("  [3] Defend       (sacrifice speed, gain +10 durability)");
            Console.WriteLine("  [4] View Stats   (display full stats)");
            Console.WriteLine();

            bool actionDone = false;
            while (!actionDone)
            {
                try
                {
                    int choice = UI.ReadInt("  Choice: ", 1, 4);
                    switch (choice)
                    {
                        case 1: ActionAccelerate();      actionDone = true; break;
                        case 2: ActionUseItem(race);     actionDone = true; break;
                        case 3: ActionDefend();          actionDone = true; break;
                        case 4: DisplayStats();          break; // stays in loop
                    }
                }
                catch (InvalidOperationException ex)
                {
                    Console.WriteLine($"  [Error] {ex.Message} Please choose another action.");
                }
            }
        }

        private void ActionAccelerate()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"  >> {Name} floors it! (Speed: {Speed})");
            Console.ResetColor();
        }

        private void ActionUseItem(Race race)
        {
            if (Inventory.Count == 0)
                throw new InvalidOperationException("No items in inventory.");

            Console.WriteLine("  Select item to use:");
            Inventory.ShowInventory();
            int idx = UI.ReadInt("  Item #: ", 1, Inventory.Count);
            Inventory.UseItem(idx, this, race);
        }

        private void ActionDefend()
        {
            int oldSpeed = Speed;
            Speed      -= 2;
            Durability  = Math.Min(100, Durability + 10);
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine($"  >> {Name} takes a defensive line. Speed {oldSpeed} -> {Speed}, Durability -> {Durability}");
            Console.ResetColor();
        }

        public void PostTurnCleanup()
        {
            if (_nitroUsedThisTurn)
            {
                RestoreSpeed();
                _nitroUsedThisTurn = false;
            }
            if (HazardResistTurnsLeft > 0) HazardResistTurnsLeft--;
        }

        public void FlagNitroUsed() => _nitroUsedThisTurn = true;
    }
}
