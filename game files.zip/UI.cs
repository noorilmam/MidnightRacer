// ============================================================
//  UI.cs  –  Console display helpers
// ============================================================
namespace MidnightCircuit
{
    public static class UI
    {
        private const int Width = 60;

        public static void Banner(string text)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(new string('═', Width));
            Console.WriteLine(text.PadLeft((Width + text.Length) / 2));
            Console.WriteLine(new string('═', Width));
            Console.ResetColor();
        }

        public static void Header(string text)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"── {text} " + new string('─', Math.Max(0, Width - text.Length - 4)));
            Console.ResetColor();
        }

        public static void SubHeader(string text)
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine($"  [{text}]");
            Console.ResetColor();
        }

        public static void Divider(string label = "")
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.DarkGray;
            if (string.IsNullOrEmpty(label))
                Console.WriteLine(new string('-', Width));
            else
                Console.WriteLine($"{'─',3} {label} " + new string('─', Math.Max(0, Width - label.Length - 5)));
            Console.ResetColor();
        }

        // Read an integer in [min, max]; keeps prompting on bad input
        public static int ReadInt(string prompt, int min, int max)
        {
            while (true)
            {
                Console.Write(prompt);
                string? input = Console.ReadLine();
                if (int.TryParse(input, out int val) && val >= min && val <= max)
                    return val;
                Console.WriteLine($"  Please enter a number between {min} and {max}.");
            }
        }

        public static string ReadName(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string? name = Console.ReadLine()?.Trim();
                if (!string.IsNullOrEmpty(name)) return name;
                Console.WriteLine("  Name cannot be blank.");
            }
        }
    }
}
