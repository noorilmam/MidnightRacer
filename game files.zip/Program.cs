// ============================================================
//  Program.cs  –  Entry point
// ============================================================
namespace MidnightCircuit
{
    internal class Program
    {
        static void Main(string[] args)
        {
            new Game().Start();
        }
    }
}
