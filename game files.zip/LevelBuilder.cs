// ============================================================
//  LevelBuilder.cs  –  Builds rival rosters for each level
// ============================================================
namespace MidnightCircuit
{
    public static class LevelBuilder
    {
        // Amateur names pool
        private static readonly string[] AmateurNames =
            { "Street Rat", "Dusty Drake", "Flip Navarro", "Bumper Jones", "Rookie Rush" };

        // Pro names pool
        private static readonly string[] ProNames =
            { "Phantom Vega", "Iron Wolf", "Shadow Mace", "Eclipse Kane", "Neon Ryder" };

        private static readonly Random _rng = new();

        /// <summary>
        /// Returns the rival list for the given level.
        /// Level 1-2  → all Amateurs
        /// Level 3    → mix
        /// Level 4+   → all Pros
        /// </summary>
        public static List<Racer> BuildRivals(int level)
        {
            var rivals = new List<Racer>();

            int amateurCount, proCount;

            if      (level == 1) { amateurCount = 3; proCount = 0; }
            else if (level == 2) { amateurCount = 2; proCount = 1; }
            else if (level == 3) { amateurCount = 1; proCount = 2; }
            else                 { amateurCount = 0; proCount = 3; }

            var aPool = new Queue<string>(AmateurNames.OrderBy(_ => _rng.Next()));
            var pPool = new Queue<string>(ProNames.OrderBy(_ => _rng.Next()));

            for (int i = 0; i < amateurCount; i++)
                rivals.Add(new AmateurRival(aPool.Dequeue()));

            for (int i = 0; i < proCount; i++)
                rivals.Add(new ProRival(pPool.Dequeue()));

            return rivals;
        }

        public static string LevelDescription(int level) => level switch
        {
            1 => "Rookie Circuit  – 3 Amateur rivals",
            2 => "Street Series  – 2 Amateurs, 1 Pro",
            3 => "Underground Cup – 1 Amateur, 2 Pros",
            _ => "Midnight Elite  – 3 Pro rivals (Drafting enabled)"
        };
    }
}
