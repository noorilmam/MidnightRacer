// ============================================================
//  Hazard.cs  –  Environmental hazard hierarchy
// ============================================================
namespace MidnightCircuit
{
    public abstract class Hazard
    {
        public string Name { get; protected set; }

        protected Hazard(string name) => Name = name;

        // Apply the hazard effect to the given racer
        public abstract void Apply(Racer target);
    }

    // ── Engine Overheating ────────────────────────────────────
    public class EngineOverheat : Hazard
    {
        private const int SpeedPenalty = 2;

        public EngineOverheat() : base("Engine Overheating") { }

        public override void Apply(Racer target)
        {
            target.ApplySpeedPenalty(SpeedPenalty);
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine($"  🔥  HAZARD – Engine Overheating hits {target.Name}! " +
                              $"Speed reduced by {SpeedPenalty} → now {target.Speed}.");
            Console.ResetColor();
        }
    }

    // ── Police Intervention ───────────────────────────────────
    public class PoliceIntervention : Hazard
    {
        private const int DurabilityPenalty = 25;
        private const int SpeedPenalty      = 1;

        private static readonly Random _rng = new();

        public PoliceIntervention() : base("Police Intervention") { }

        public override void Apply(Racer target)
        {
            // 30 % chance of severe: eliminates the racer outright
            bool severe = _rng.Next(100) < 30;

            Console.ForegroundColor = ConsoleColor.Blue;
            if (severe)
            {
                target.TakeDamage(target.Durability); // sets durability to 0 → eliminated
                Console.WriteLine($"  🚨  SEVERE POLICE BUST! {target.Name} is ELIMINATED from the race!");
            }
            else
            {
                target.TakeDamage(DurabilityPenalty);
                target.ApplySpeedPenalty(SpeedPenalty);
                Console.WriteLine($"  🚔  Police chase! {target.Name} loses {DurabilityPenalty} durability " +
                                  $"and {SpeedPenalty} speed.");
            }
            Console.ResetColor();
        }
    }

    // ── Road Debris ───────────────────────────────────────────
    public class RoadDebris : Hazard
    {
        private const int DurabilityPenalty = 10;

        public RoadDebris() : base("Road Debris") { }

        public override void Apply(Racer target)
        {
            target.TakeDamage(DurabilityPenalty);
            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine($"  🪨  Road Debris! {target.Name} takes {DurabilityPenalty} durability damage " +
                              $"→ now {target.Durability}.");
            Console.ResetColor();
        }
    }

    // ── Hazard Factory ────────────────────────────────────────
    public static class HazardFactory
    {
        private static readonly Random _rng = new();

        private static readonly List<Func<Hazard>> _pool = new()
        {
            () => new EngineOverheat(),
            () => new PoliceIntervention(),
            () => new RoadDebris()
        };

        public static Hazard GetRandom() => _pool[_rng.Next(_pool.Count)]();
    }
}
