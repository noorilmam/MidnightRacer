// ============================================================
//  Race.cs  –  Turn-based race loop manager
// ============================================================
namespace MidnightCircuit
{
    public class Race
    {
        // ── Configuration ────────────────────────────────────
        public int    TotalLaps       { get; }
        public int    Level           { get; }
        public double HazardChance    { get; }   // 0.0–1.0

        // ── State shared by rivals ───────────────────────────
        public int    EmpJammedTurnsLeft { get; set; } = 0;

        // Laps left of whoever is currently leading (used by ProRival for Drafting)
        public int    LeaderLapsLeft     { get; private set; }

        // ── Participants ─────────────────────────────────────
        private readonly Player        _player;
        private readonly List<Racer>   _rivals;
        private readonly Random        _rng = new();

        public Race(Player player, List<Racer> rivals, int level)
        {
            _player  = player;
            _rivals  = rivals;
            Level    = level;
            TotalLaps     = 10;
            HazardChance  = 0.15 + (level - 1) * 0.05;   // 15 % base, +5 % per level

            player.ResetForRace(TotalLaps);
            foreach (var r in rivals) r.LapsLeft = TotalLaps;   // LapsLeft setter via reflection-friendly property
        }

        // ── Main entry point ─────────────────────────────────
        public bool Run()
        {
            UI.Banner($"  RACE START  –  Level {Level}  ({TotalLaps} laps)");
            Console.WriteLine($"  Hazard probability per turn: {HazardChance:P0}");
            Console.WriteLine();

            int turn = 0;

            while (true)
            {
                turn++;
                UI.Divider($"TURN {turn}");

                // 1. Player acts
                _player.PerformAction(this);

                // 2. Rivals act
                Console.WriteLine();
                foreach (var rival in _rivals.Where(r => !r.IsEliminated))
                    rival.PerformAction(this);

                // 3. Advance laps
                Console.WriteLine();
                UI.SubHeader("LAP UPDATE");
                UpdateLeader();

                _player.AdvanceLaps();
                foreach (var rival in _rivals.Where(r => !r.IsEliminated))
                    rival.AdvanceLaps();

                PrintStandings();

                // 4. Hazard phase
                Console.WriteLine();
                RollHazards();

                // 5. Cleanup
                if (EmpJammedTurnsLeft > 0) EmpJammedTurnsLeft--;
                _player.PostTurnCleanup();

                // 6. Win / loss check
                bool? result = CheckFinish();
                if (result.HasValue) return result.Value;
            }
        }

        // ── Helpers ──────────────────────────────────────────

        private void UpdateLeader()
        {
            // Leader is the racer with fewest laps remaining
            int min = _player.LapsLeft;
            foreach (var r in _rivals.Where(r => !r.IsEliminated))
                min = Math.Min(min, r.LapsLeft);
            LeaderLapsLeft = min;
        }

        private void RollHazards()
        {
            if (_rng.NextDouble() >= HazardChance) return;

            // Pick a random non-eliminated target (player or rival)
            var targets = new List<Racer> { _player };
            targets.AddRange(_rivals.Where(r => !r.IsEliminated));

            var target  = targets[_rng.Next(targets.Count)];
            var hazard  = HazardFactory.GetRandom();

            // Player may be immune this turn
            if (target == _player && _player.HazardResistTurnsLeft > 0)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"  🛡  {hazard.Name} was deflected by your Performance Tires!");
                Console.ResetColor();
                return;
            }

            hazard.Apply(target);
        }

        private bool? CheckFinish()
        {
            // Player wins if they have crossed the finish (laps <= 0)
            if (_player.LapsLeft <= 0)
            {
                Console.WriteLine();
                UI.Banner("  🏆  YOU WIN THE RACE!  🏆");
                return true;
            }

            // Player loses if eliminated
            if (_player.IsEliminated)
            {
                Console.WriteLine();
                UI.Banner("  💀  YOUR CAR IS OUT OF COMMISSION. RACE LOST.");
                return false;
            }

            // Check if all rivals are done or eliminated
            bool allRivalsGone = _rivals.All(r => r.LapsLeft <= 0 || r.IsEliminated);
            if (allRivalsGone)
            {
                Console.WriteLine();
                UI.Banner("  🏆  ALL RIVALS FINISHED / ELIMINATED – YOU WIN!  🏆");
                return true;
            }

            return null; // race continues
        }

        private void PrintStandings()
        {
            Console.WriteLine($"  {"Player",-18} {_player}");
            foreach (var r in _rivals)
            {
                string status = r.IsEliminated ? " [ELIMINATED]" : r.LapsLeft <= 0 ? " [FINISHED]" : "";
                Console.WriteLine($"  {"Rival",-18} {r}{status}");
            }
        }
    }
}
