// ============================================================
//  Racer.cs  –  Abstract base class for all racers
//  Implements: IDamageable, IDisplayable
// ============================================================
namespace MidnightCircuit
{
    public abstract class Racer : IDamageable, IDisplayable
    {
        // ── Private backing fields (Encapsulation) ────────────
        private string _name;
        private int    _speed;
        private int    _baseSpeed;
        private int    _durability;
        private int    _lapsLeft;

        // ── Public properties with controlled access ──────────
        public string Name
        {
            get => _name;
            protected set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Racer name cannot be empty.");
                _name = value;
            }
        }

        public int Speed
        {
            get => _speed;
            set => _speed = Math.Max(1, value);
        }

        public int BaseSpeed
        {
            get => _baseSpeed;
            private set => _baseSpeed = Math.Max(1, value);
        }

        public int Durability
        {
            get => _durability;
            set => _durability = Math.Clamp(value, 0, 100);
        }

        public int LapsLeft
        {
            get => _lapsLeft;
            set => _lapsLeft = Math.Max(0, value);
        }

        public bool IsEliminated => Durability <= 0;

        // ── Constructor ───────────────────────────────────────
        protected Racer(string name, int speed, int durability, int totalLaps)
        {
            _name      = string.Empty;
            Name       = name;
            Speed      = speed;
            BaseSpeed  = speed;
            Durability = durability;
            LapsLeft   = totalLaps;
        }

        // ── Abstract method – each subclass must implement ────
        public abstract void PerformAction(Race race);

        // ── IDamageable ───────────────────────────────────────
        public void TakeDamage(int amount)
        {
            if (amount < 0) throw new ArgumentOutOfRangeException(nameof(amount), "Damage cannot be negative.");
            Durability -= amount;
        }

        // ── IDisplayable ──────────────────────────────────────
        public virtual void DisplayStats()
        {
            Console.WriteLine($"  Name       : {Name}");
            Console.WriteLine($"  Speed      : {Speed}");
            Console.WriteLine($"  Durability : {Durability}");
            Console.WriteLine($"  Laps Left  : {LapsLeft}");
            Console.WriteLine($"  Eliminated : {IsEliminated}");
        }

        // ── Shared helpers ────────────────────────────────────
        public void AdvanceLaps()
        {
            if (IsEliminated) return;
            LapsLeft = Math.Max(0, LapsLeft - Speed);
        }

        public void ApplySpeedPenalty(int amount)
        {
            if (amount < 0) throw new ArgumentOutOfRangeException(nameof(amount), "Penalty cannot be negative.");
            Speed -= amount;
        }

        public void RestoreSpeed() => Speed = BaseSpeed;

        public override string ToString() =>
            $"{Name,-18} | Laps left: {LapsLeft,3} | Speed: {Speed,2} | Durability: {Durability,3}";
    }
}
