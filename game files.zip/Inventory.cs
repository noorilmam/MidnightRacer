// ============================================================
//  Inventory.cs  –  Holds and manages the player's items
// ============================================================
namespace MidnightCircuit
{
    public class Inventory
    {
        // Collection: List<Item> as required by rubric
        private readonly List<Item> _items = new();

        public int Count => _items.Count;

        public void AddItem(Item item)
        {
            if (item == null) throw new ArgumentNullException(nameof(item), "Cannot add a null item.");
            _items.Add(item);
            Console.WriteLine($"  + {item.Name} added to inventory.");
        }

        public Item? GetItem(int oneBased)
        {
            if (oneBased < 1 || oneBased > _items.Count)
                throw new ArgumentOutOfRangeException(nameof(oneBased),
                    $"Item index must be between 1 and {_items.Count}.");
            return _items[oneBased - 1];
        }

        public bool UseItem(int oneBased, Player player, Race race)
        {
            try
            {
                Item? item = GetItem(oneBased);
                if (item == null) return false;
                item.Use(player, race);
                _items.RemoveAt(oneBased - 1);
                return true;
            }
            catch (ArgumentOutOfRangeException ex)
            {
                Console.WriteLine($"  [Error] Invalid item selection: {ex.Message}");
                return false;
            }
        }

        public void ShowInventory()
        {
            if (_items.Count == 0)
            {
                Console.WriteLine("  (inventory is empty)");
                return;
            }
            for (int i = 0; i < _items.Count; i++)
                Console.WriteLine($"  [{i + 1}] {_items[i]}");
        }
    }
}
