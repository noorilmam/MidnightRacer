// ============================================================
//  Interfaces.cs  –  Core interfaces used across the system
// ============================================================
namespace MidnightCircuit
{
    /// <summary>
    /// Any item that can be used/consumed by the player during a race.
    /// </summary>
    public interface IUsable
    {
        string Name        { get; }
        int    Cost        { get; }
        string Description { get; }
        void Use(Player player, Race race);
    }

    /// <summary>
    /// Any entity that can display its own status to the console.
    /// </summary>
    public interface IDisplayable
    {
        void DisplayStats();
    }

    /// <summary>
    /// Any racer entity that can take damage and be checked for elimination.
    /// </summary>
    public interface IDamageable
    {
        int  Durability    { get; }
        bool IsEliminated  { get; }
        void TakeDamage(int amount);
    }
}
