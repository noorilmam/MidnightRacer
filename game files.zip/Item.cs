// ============================================================
//  Item.cs  –  Abstract Item base + concrete item types
//  Implements: IUsable
// ============================================================
namespace MidnightCircuit
{
    // ── Abstract base (implements IUsable) ───────────────────
    public abstract class Item : IUsable
    {
        // Private backing fields
        private string _name;
        private int    _cost;
        private string _description;

        public string Name
        {
            get => _name;
            protected set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException("Item name cannot be empty.");
                _name = value;
            }
        }

        public int Cost
        {
            get => _cost;
            protected set
            {
                if (value < 0) throw new ArgumentOutOfRangeException(nameof(value), "Cost cannot be negative.");
                _cost = value;
            }
        }

        public string Description
        {
            get => _description;
            protected set => _description = value ?? string.Empty;
        }

        protected Item(string name, int cost, string description)
        {
            _name        = string.Empty;
            _description = string.Empty;
            Name         = name;
            Cost         = cost;
            Description  = description;
        }

        // Each item subclass defines what happens when used
        public abstract void Use(Player player, Race race);

        public override string ToString() => $"{Name,-20} ${Cost,4}  -  {Description}";
    }

    // ── Nitro ─────────────────────────────────────────────────
    public class Nitro : Item
    {
        private const int SpeedBoost = 3;

        public Nitro() : base("Nitro Boost", 500,
            $"Adds +{SpeedBoost} speed for 1 turn (single use)") { }

        public override void Use(Player player, Race race)
        {
            if (player == null) throw new ArgumentNullException(nameof(player));
            player.Speed += SpeedBoost;
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"  >> {player.Name} fires the NITRO! Speed jumps to {player.Speed} this turn.");
            Console.ResetColor();
        }
    }

    // ── Performance Tires ─────────────────────────────────────
    public class PerformanceTires : Item
    {
        private const int DurabilityRestore = 20;
        private const int HazardResistTurns = 3;

        public PerformanceTires() : base("Performance Tires", 800,
            $"Restores {DurabilityRestore} durability & hazard resist for {HazardResistTurns} turns") { }

        public override void Use(Player player, Race race)
        {
            if (player == null) throw new ArgumentNullException(nameof(player));
            player.Durability = Math.Min(100, player.Durability + DurabilityRestore);
            player.HazardResistTurnsLeft = HazardResistTurns;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"  >> {player.Name} fits Performance Tires! " +
                              $"Durability -> {player.Durability}. Hazard resist for {HazardResistTurns} turns.");
            Console.ResetColor();
        }
    }

    // ── EMP Jammer ────────────────────────────────────────────
    public class EmpJammer : Item
    {
        public EmpJammer() : base("EMP Jammer", 1200,
            "Disables Pro rival Drafting bonuses for 2 turns") { }

        public override void Use(Player player, Race race)
        {
            if (race == null) throw new ArgumentNullException(nameof(race));
            race.EmpJammedTurnsLeft = 2;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"  >> {player.Name} deploys the EMP Jammer! Pro rivals lose Drafting for 2 turns.");
            Console.ResetColor();
        }
    }
}
