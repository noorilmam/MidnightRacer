// ============================================================
//  Rivals.cs  –  AmateurRival and ProRival (extend Racer)
// ============================================================
namespace MidnightCircuit
{
    // ── Amateur Rival ─────────────────────────────────────────
    public class AmateurRival : Racer
    {
        private static readonly Random _rng = new();

        public AmateurRival(string name) : base(name, speed: 4, durability: 80, totalLaps: 10) { }

        // Polymorphism: simple logic - occasionally fumbles
        public override void PerformAction(Race race)
        {
            if (race == null) throw new ArgumentNullException(nameof(race));

            if (_rng.Next(100) < 20)
            {
                Speed = Math.Max(1, Speed - 1);
                Console.WriteLine($"  >> {Name} (Amateur) fumbles the corner. Speed drops to {Speed}.");
            }
            else
            {
                RestoreSpeed();
                Console.WriteLine($"  >> {Name} (Amateur) accelerates. (Speed: {Speed})");
            }
        }

        public override void DisplayStats()
        {
            Console.WriteLine($"  [{Name}] Type: Amateur Rival | Speed: {Speed} | Durability: {Durability} | Laps Left: {LapsLeft}");
        }
    }

    // ── Pro Rival ─────────────────────────────────────────────
    public class ProRival : Racer
    {
        private const int DraftingThreshold = 3;
        private const int DraftingBonus     = 2;

        private static readonly Random _rng = new();

        public ProRival(string name) : base(name, speed: 5, durability: 100, totalLaps: 10) { }

        // Polymorphism: advanced logic - uses Drafting mechanic
        public override void PerformAction(Race race)
        {
            if (race == null) throw new ArgumentNullException(nameof(race));

            RestoreSpeed();

            if (race.EmpJammedTurnsLeft <= 0)
            {
                int gapToLeader = LapsLeft - race.LeaderLapsLeft;

                if (gapToLeader <= DraftingThreshold && gapToLeader >= 0)
                {
                    Speed += DraftingBonus;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"  >> {Name} (Pro) DRAFTING! Speed surges to {Speed}.");
                    Console.ResetColor();
                    return;
                }
            }

            Console.WriteLine($"  >> {Name} (Pro) drives precisely. (Speed: {Speed})");
        }

        public override void DisplayStats()
        {
            Console.WriteLine($"  [{Name}] Type: Pro Rival | Speed: {Speed} | Durability: {Durability} | Laps Left: {LapsLeft}");
        }
    }
}
